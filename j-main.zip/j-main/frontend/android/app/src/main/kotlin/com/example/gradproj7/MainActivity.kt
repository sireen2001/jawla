package com.example.gradproj7

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
